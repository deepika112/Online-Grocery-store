function submitForm(obj,a){
    var id = document.getElementById("qty").value;
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert(this.responseText);
    }
  };
  xhr.open('POST', 'http://localhost/Groceries/PhpFolder/Cart.php',true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
//   xhr.onload = function() {
//     if (xhr.status === 200) {
//       // do something with the response if needed
//       alert("HI");
//     }
//   };
//   var formData = new FormData(document.getElementById('myForm'));
  xhr.send("id="+id+"a="+a);
}